package eda.algorithms;

public interface MazeGenerator {
    Maze generate(int rows, int cols);
}
